import { MdOutlineBedroomChild } from "react-icons/md";

export const productCategory = [
  {
    id: 1,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 2,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 3,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 4,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 5,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 6,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 7,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 8,
    name: "Beachfront",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 9,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 10,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 11,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 12,
    name: "Beachfront",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 13,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 14,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 15,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 16,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 17,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 18,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 19,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 20,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 21,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 22,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 23,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 24,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 24,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 25,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 26,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 27,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 28,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 28,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 28,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 28,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 28,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 28,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 28,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 28,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 28,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 28,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 28,
    name: "Beachfront",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 28,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 28,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 28,
    name: "Beachfront",
    icon: <MdOutlineBedroomChild />,
  },
  {
    id: 28,
    name: "icons",
    icon: <MdOutlineBedroomChild />,
  },
];

export const product = [
  {
    id: 1,

    title: "Playdate at Polly Pocket’s Compact",
    short_dis: "Hosted by Polly Pocket",
    price: "$35 per guest",
    image: [
      {
        id: 1,
        img: "/assets/images/product/1.webp",
      },
      {
        id: 2,
        img: "/assets/images/product/2.webp",
      },
      {
        id: 3,
        img: "/assets/images/product/3.webp",
      },
      {
        id: 4,
        img: "/assets/images/product/4.webp",
      },
    ],
  },
  {
    id: 2,
    title: "Playdate at Polly Pocket’s Compact",
    short_dis: "Hosted by Polly Pocket",
    price: "$35 per guest",
    image: [
      {
        id: 1,
        img: "/assets/images/product/5.webp",
      },
      {
        id: 2,
        img: "/assets/images/product/2.webp",
      },
      {
        id: 3,
        img: "/assets/images/product/3.webp",
      },
      {
        id: 4,
        img: "/assets/images/product/4.webp",
      },
    ],
  },
  {
    id: 3,
    title: "Playdate at Polly Pocket’s Compact",
    short_dis: "Hosted by Polly Pocket",
    price: "$35 per guest",
    image: [
      {
        id: 1,
        img: "/assets/images/product/5.webp",
      },
      {
        id: 2,
        img: "/assets/images/product/2.webp",
      },
      {
        id: 3,
        img: "/assets/images/product/3.webp",
      },
      {
        id: 4,
        img: "/assets/images/product/4.webp",
      },
    ],
  },
  {
    id: 4,
    title: "Playdate at Polly Pocket’s Compact",
    short_dis: "Hosted by Polly Pocket",
    price: "$35 per guest",
    image: [
      {
        id: 1,
        img: "/assets/images/product/3.webp",
      },
      {
        id: 2,
        img: "/assets/images/product/2.webp",
      },
      {
        id: 3,
        img: "/assets/images/product/3.webp",
      },
      {
        id: 4,
        img: "/assets/images/product/4.webp",
      },
    ],
  },
  {
    id: 5,
    title: "Playdate at Polly Pocket’s Compact",
    short_dis: "Hosted by Polly Pocket",
    price: "$35 per guest",
    image: [
      {
        id: 1,
        img: "/assets/images/product/1.webp",
      },
      {
        id: 2,
        img: "/assets/images/product/2.webp",
      },
      {
        id: 3,
        img: "/assets/images/product/3.webp",
      },
      {
        id: 4,
        img: "/assets/images/product/4.webp",
      },
    ],
  },
  {
    id: 6,
    title: "Playdate at Polly Pocket’s Compact",
    short_dis: "Hosted by Polly Pocket",
    price: "$35 per guest",
    image: [
      {
        id: 1,
        img: "/assets/images/product/5.webp",
      },
      {
        id: 2,
        img: "/assets/images/product/2.webp",
      },
      {
        id: 3,
        img: "/assets/images/product/3.webp",
      },
      {
        id: 4,
        img: "/assets/images/product/4.webp",
      },
    ],
  },
 
];
export const productPast = [
  {
    id: 11,

    title: "Playdate at Polly Pocket’s Compact",
    short_dis: "Hosted by Polly Pocket",
    price: "$35 per guest",
    image: [
      {
        id: 1,
        img: "/assets/images/product/4.webp",
      },
      {
        id: 2,
        img: "/assets/images/product/2.webp",
      },
      {
        id: 3,
        img: "/assets/images/product/3.webp",
      },
      {
        id: 4,
        img: "/assets/images/product/4.webp",
      },
    ],
  },
  {
    id: 12,
    title: "Playdate at Polly Pocket’s Compact",
    short_dis: "Hosted by Polly Pocket",
    price: "$35 per guest",
    image: [
      {
        id: 1,
        img: "/assets/images/product/3.webp",
      },
      {
        id: 2,
        img: "/assets/images/product/2.webp",
      },
      {
        id: 3,
        img: "/assets/images/product/3.webp",
      },
      {
        id: 4,
        img: "/assets/images/product/4.webp",
      },
    ],
  },
  {
    id: 13,
    title: "Playdate at Polly Pocket’s Compact",
    short_dis: "Hosted by Polly Pocke",
    price: "$35 per guest",
    image: [
      {
        id: 1,
        img: "/assets/images/product/4.webp",
      },
      {
        id: 2,
        img: "/assets/images/product/2.webp",
      },
      {
        id: 3,
        img: "/assets/images/product/3.webp",
      },
      {
        id: 4,
        img: "/assets/images/product/4.webp",
      },
    ],
  },
  {
    id: 14,
    title: "Playdate at Polly Pocket’s Compact",
    short_dis: "Hosted by Polly Pocket",
    price: "$35 per guest",
    image: [
      {
        id: 1,
        img: "/assets/images/product/5.webp",
      },
      {
        id: 2,
        img: "/assets/images/product/2.webp",
      },
      {
        id: 3,
        img: "/assets/images/product/3.webp",
      },
      {
        id: 4,
        img: "/assets/images/product/4.webp",
      },
    ],
  },
  {
    id: 15,
    title: "Playdate at Polly Pocket’s Compact",
    short_dis: "Hosted by Polly Pocket",
    price: "$35 per guest",
    image: [
      {
        id: 1,
        img: "/assets/images/product/1.webp",
      },
      {
        id: 2,
        img: "/assets/images/product/2.webp",
      },
      {
        id: 3,
        img: "/assets/images/product/3.webp",
      },
      {
        id: 4,
        img: "/assets/images/product/4.webp",
      },
    ],
  },
  {
    id: 16,
    title: "Playdate at Polly Pocket’s Compact",
    short_dis: "Hosted by Polly Pocket",
    price: "$35 per guest",
    image: [
      {
        id: 1,
        img: "/assets/images/product/1.webp",
      },
      {
        id: 2,
        img: "/assets/images/product/2.webp",
      },
      {
        id: 3,
        img: "/assets/images/product/3.webp",
      },
      {
        id: 4,
        img: "/assets/images/product/4.webp",
      },
    ],
  },
 
];

export const popular= [
  {
    id: 1,
    name: "Canmore",
    rental: "Apartment rentals",
  },
  {
    id: 2,
    name: "Canmore",
    rental: "Apartment rentals",
  },
  {
    id: 2,
    name: "Canmore",
    rental: "Apartment rentals",
  },
  {
    id: 2,
    name: "Canmore",
    rental: "Apartment rentals",
  },
  {
    id: 2,
    name: "Canmore",
    rental: "Apartment rentals",
  },
  {
    id: 2,
    name: "Canmore",
    rental: "Apartment rentals",
  },
  {
    id: 2,
    name: "Canmore",
    rental: "Apartment rentals",
  },
  {
    id: 2,
    name: "Canmore",
    rental: "Apartment rentals",
  },
  {
    id: 2,
    name: "Canmore",
    rental: "Apartment rentals",
  },
  {
    id: 2,
    name: "Canmore",
    rental: "Apartment rentals",
  },
  {
    id: 2,
    name: "Canmore",
    rental: "Apartment rentals",
  },

];
export const artsCulture = [
  {
    id: 1,
    name: "Phoenix",
    rental: "Condo rentals",
  },
  {
    id: 2,
    name: "Canmore",
    rental: "Condo rentals",
  },
  {
    id: 2,
    name: "Canmore",
    rental: "Condo rentals",
  },
  {
    id: 2,
    name: "Phoenix",
    rental: "Condo rentals",
  },
  {
    id: 2,
    name: "Phoenix",
    rental: "Condo rentals",
  },
  {
    id: 2,
    name: "Phoenix",
    rental: "Condo rentals",
  },
  {
    id: 2,
    name: "Phoenix",
    rental: "Condo rentals",
  },
  {
    id: 2,
    name: "Canmore",
    rental: "Condo rentals",
  },
  {
    id: 2,
    name: "Canmore",
    rental: "Condo rentals",
  },
  {
    id: 2,
    name: "Canmore",
    rental: "Condo rentals",
  },
  {
    id: 2,
    name: "Canmore",
    rental: "Condo rentals",
  },
];

export const support=[
  {
    id:1,
    name:'Help Center',
    link:'#'
  },
  {
    id:2,
    name:'AirCover',
    link:'#'
  },
  {
    id:3,
    name:'Anti-discrimination',
    link:'#'
  },
  {
    id:4,
    name:'Disability support',
    link:'#'
  },
  {
    id:5,
    name:'Cancellation options',
    link:'#'
  },
  {
    id:6,
    name:'Report neighborhood concern',
    link:'#'
  },
]
export const hosting=[
  {
    id:1,
    name:'Airbnb your home',
    link:'#'
  },
  {
    id:2,
    name:'AirCover for Hosts',
    link:'#'
  },
  {
    id:3,
    name:'Hosting resources',
    link:'#'
  },
  {
    id:4,
    name:'Community forum',
    link:'#'
  },
  {
    id:5,
    name:'Hosting responsibly',
    link:'#'
  },
  {
    id:6,
    name:'Airbnb-friendly apartments',
    link:'#'
  },
  {
    id:7,
    name:'Join a free Hosting class',
    link:'#'
  },
]
export const airbnb=[
  {
    id:1,
    name:'Newsroom',
    link:'#'
  },
  {
    id:2,
    name:'New features',
    link:'#'
  },
  {
    id:3,
    name:'Careers',
    link:'#'
  },
  {
    id:4,
    name:'Investors',
    link:'#'
  },
  {
    id:5,
    name:'Gift cards',
    link:'#'
  },
  {
    id:6,
    name:'Airbnb.org emergency stays',
    link:'#'
  },
]







