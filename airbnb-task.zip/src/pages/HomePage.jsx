import Inspiration from "../components/Inspiration"
import Product from "../components/Product"

const HomePage = () => {
  return (
    <>
    {/* ================= Product =========== */}
    <Product/>
    <Inspiration/>
    
    </>
  )
}

export default HomePage